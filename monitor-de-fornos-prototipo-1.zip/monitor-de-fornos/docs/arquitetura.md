# Arquitetura

ESP8266 mede a temperatura e envia JSON por HTTPS. O Google Apps Script recebe e grava na planilha. O dashboard consulta `?action=latest` a cada 10 segundos. Depois, para produção, migrar para MQTT/WebSocket + banco de dados.
